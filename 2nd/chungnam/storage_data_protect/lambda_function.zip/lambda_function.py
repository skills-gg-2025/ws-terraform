import json
import boto3
import re
from urllib.parse import unquote_plus

s3 = boto3.client('s3')

def lambda_handler(event, context):
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = unquote_plus(record['s3']['object']['key'])
        
        if not key.startswith('incoming/'):
            continue
            
        try:
            response = s3.get_object(Bucket=bucket, Key=key)
            content = response['Body'].read().decode('utf-8')
            
            # Mask sensitive data
            masked_content = mask_sensitive_data(content)
            
            # Save to masked/ prefix
            new_key = key.replace('incoming/', 'masked/')
            s3.put_object(
                Bucket=bucket, 
                Key=new_key, 
                Body=masked_content,
                ContentType='text/plain'
            )
            
            print(f"Successfully processed {key} -> {new_key}")
            
        except Exception as e:
            print(f"Error processing {key}: {str(e)}")
            import traceback
            traceback.print_exc()
    
    return {'statusCode': 200}

def mask_sensitive_data(content):
    lines = content.split('\n')
    masked_lines = []
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
            
        # Names - mask last name (Crystal White -> Crystal *****)
        if re.match(r'^[A-Za-z]+ [A-Za-z]+$', line):
            parts = line.split(' ')
            masked_lines.append(f"{parts[0]} *****")
        
        # Emails - mask username part (davisjesus@example.org -> d*********@example.org)
        elif '@' in line:
            match = re.match(r'^([a-zA-Z])[^@]*(@.+)$', line)
            if match:
                masked_lines.append(f"{match.group(1)}*********{match.group(2)}")
            else:
                masked_lines.append(line)
        
        # Phone numbers - mask last 4 digits (010-7658-5153 -> 010-7658-****)
        elif re.match(r'^\d{3}-\d{4}-\d{4}$', line):
            masked_lines.append(re.sub(r'(\d{3}-\d{4}-)(\d{4})', r'\1****', line))
        
        # SSNs - mask last 4 digits (887-07-7325 -> 887-07-****)
        elif re.match(r'^\d{3}-\d{2}-\d{4}$', line):
            masked_lines.append(re.sub(r'(\d{3}-\d{2}-)(\d{4})', r'\1****', line))
        
        # Credit cards - mask last 4 digits (4468-6779-7028-4776 -> 4468-6779-7028-****)
        elif re.match(r'^\d{4}-\d{4}-\d{4}-\d{4}$', line):
            masked_lines.append(re.sub(r'(\d{4}-\d{4}-\d{4}-)(\d{4})', r'\1****', line))
        
        # UUIDs - mask last 12 characters
        elif re.match(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$', line):
            masked_lines.append(re.sub(r'([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-)([0-9a-f]{12})', r'\1************', line))
        
        else:
            masked_lines.append(line)
    
    return '\n'.join(masked_lines)
